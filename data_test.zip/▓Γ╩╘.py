import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import chi2_contingency

# =========================
# 0. 保存路径：当前脚本所在目录
# =========================
base_dir = os.path.dirname(os.path.abspath(__file__))

# =========================
# 1. 读取 CSV
# =========================
# sample数据集
# csv_path = r"D:\Desktop\大三下\MIS2001\project\elderly_insurance_sample_20.csv"
# test数据集
csv_path = r"D:\Desktop\大三下\MIS2001\project\elderly_insurance_test_200_similar_to_sample.csv"
df = pd.read_csv(csv_path, encoding="utf-8-sig")

# 如数据超过200条，则抽样200条
if len(df) > 200:
    df = df.sample(n=200, random_state=42).reset_index(drop=True)

# =========================
# 2. 基础设置
# =========================
risk_order = ["低风险", "中低风险", "中风险", "中高风险", "高风险"]

insurance_types = ["医疗险", "意外险", "防癌险", "重疾险", "护理险", "寿险"]

risk_name_map = {
    "低风险": "Low",
    "中低风险": "Medium-Low",
    "中风险": "Medium",
    "中高风险": "Medium-High",
    "高风险": "High"
}

insurance_name_map = {
    "医疗险": "Medical",
    "意外险": "Accident",
    "防癌险": "Cancer",
    "重疾险": "Critical Illness",
    "护理险": "Care",
    "寿险": "Life"
}

# =========================
# 3. 拆分保险组合为 0/1 标签
# =========================
for ins in insurance_types:
    df[ins] = df["insurance_combo"].astype(str).apply(
        lambda x: 1 if ins in x else 0
    )

# =====================================================
# 图1：Risk Level vs Recommended Insurance Types
# Stacked Bar Chart
# =====================================================

risk_insurance_counts = df.groupby("risk_level")[insurance_types].sum()
risk_insurance_counts = risk_insurance_counts.reindex(risk_order).fillna(0)

risk_insurance_ratio = risk_insurance_counts.div(
    risk_insurance_counts.sum(axis=1), axis=0
).fillna(0)

# 风险等级转英文
risk_insurance_ratio = risk_insurance_ratio.rename(index=risk_name_map)

plt.figure(figsize=(11, 6))

bottom = np.zeros(len(risk_insurance_ratio))

for ins in insurance_types:
    values = risk_insurance_ratio[ins].values
    plt.bar(
        risk_insurance_ratio.index,
        values,
        bottom=bottom,
        label=insurance_name_map[ins]
    )
    bottom += values

plt.title("Risk Level vs Recommended Insurance Types", fontsize=16)
plt.xlabel("Risk Level", fontsize=12)
plt.ylabel("Proportion of Recommended Insurance Types", fontsize=12)
plt.xticks(rotation=0)
plt.legend(title="Insurance Type", bbox_to_anchor=(1.05, 1), loc="upper left")
plt.tight_layout()
# sample
# plt.savefig(
#     os.path.join(base_dir, "risk_vs_insurance_stacked_bar.png"),
#     dpi=300
# )
# test
plt.savefig(os.path.join(base_dir, "test200_risk_vs_insurance_stacked_bar.png"), dpi=300)

plt.show()


# =====================================================
# 图2：Questionnaire Variables Across Risk Levels
# Heatmap
# =====================================================

key_variables = [
    "age_group",
    "insurance_status",
    "financial_level",
    "family_support",
    "dependents_pressure",
    "family_buffer",
    "chronic_conditions",
    "hospitalization",
    "medication",
    "mobility",
    "adl",
    "memory"
]

variable_name_map = {
    "age_group": "Age",
    "insurance_status": "Medical Insurance Status",
    "financial_level": "Financial Level",
    "family_support": "Family Support",
    "dependents_pressure": "Dependent Pressure",
    "family_buffer": "Family Buffer",
    "chronic_conditions": "Chronic Conditions",
    "hospitalization": "Hospitalization",
    "medication": "Medication",
    "mobility": "Mobility",
    "adl": "ADL Ability",
    "memory": "Memory Condition"
}

encoding_maps = {
    "age_group": {
        "45及以下": 0,
        "45岁及以下": 0,
        "46-50": 1,
        "46–50": 1,
        "51-59": 2,
        "51–59": 2,
        "60-69": 3,
        "60–69": 3,
        "70-74": 4,
        "70–74": 4,
        "75+": 5,
        "75岁及以上": 5
    },
    "insurance_status": {
        "职工医保": 0,
        "居民医保": 1,
        "城乡居民医保": 1,
        "城乡居民医保（新农合）": 1,
        "无医保": 5,
        "无任何医保": 5
    },
    "financial_level": {
        "A": 0,
        "B": 1,
        "C": 3,
        "D": 4,
        "E": 5
    },
    "family_support": {
        "已婚稳定": 0,
        "已婚一般": 1,
        "独居有子女": 2,
        "独居有支持": 2,
        "独居不稳定": 4,
        "独居无支持": 5
    },
    "dependents_pressure": {
        "无": 0,
        "1人": 1,
        "2人": 3,
        "3人": 4,
        "4人及以上": 5
    },
    "family_buffer": {
        "A": 0,
        "B": 1,
        "C": 3,
        "D": 4,
        "E": 5
    },
    "chronic_conditions": {
        "无": 0,
        "高血压": 1,
        "糖尿病": 2,
        "高血压+糖尿病": 3,
        "多病": 4,
        "重疾": 5,
        "癌症": 5,
        "中风": 5,
        "肾病": 5
    },
    "hospitalization": {
        "无": 0,
        "一次": 3,
        "多次": 5
    },
    "medication": {
        "无": 0,
        "1药": 2,
        "1-2药": 2,
        "2药": 2,
        "3药": 4,
        "3+": 4
    },
    "mobility": {
        "正常": 0,
        "助行器": 2,
        "需要帮助": 4,
        "轮椅": 5
    },
    "adl": {
        "无": 0,
        "轻度": 1,
        "中度": 2,
        "重度": 5
    },
    "memory": {
        "无": 0,
        "轻微": 1,
        "下降": 3,
        "严重": 5
    }
}

encoded_df = df.copy()

for col in key_variables:
    encoded_df[col + "_score"] = encoded_df[col].map(encoding_maps[col])

score_columns = [col + "_score" for col in key_variables]

heatmap_data = encoded_df.groupby("risk_level")[score_columns].mean()
heatmap_data = heatmap_data.reindex(risk_order)

# 风险等级转英文
heatmap_data = heatmap_data.rename(index=risk_name_map)

# 变量名转英文
heatmap_data.columns = [
    variable_name_map[col.replace("_score", "")]
    for col in heatmap_data.columns
]

plt.figure(figsize=(13, 7))

plt.imshow(heatmap_data.T, aspect="auto")

plt.colorbar(label="Average Questionnaire Risk Score")
plt.title("Questionnaire Variables Across Risk Levels", fontsize=16)
plt.xlabel("Risk Level", fontsize=12)
plt.ylabel("Questionnaire Variables", fontsize=12)

plt.xticks(
    ticks=np.arange(len(heatmap_data.index)),
    labels=heatmap_data.index,
    rotation=0
)

plt.yticks(
    ticks=np.arange(len(heatmap_data.columns)),
    labels=heatmap_data.columns
)

for i in range(len(heatmap_data.columns)):
    for j in range(len(heatmap_data.index)):
        value = heatmap_data.iloc[j, i]
        if not np.isnan(value):
            plt.text(
                j,
                i,
                f"{value:.1f}",
                ha="center",
                va="center",
                fontsize=9
            )

plt.tight_layout()
# sample
# plt.savefig(
#     os.path.join(base_dir, "questionnaire_variables_heatmap.png"),
#     dpi=300
# )
# test
plt.savefig(os.path.join(base_dir, "test200_questionnaire_variables_heatmap.png"), dpi=300)
plt.show()


# =====================================================
# 3. Chi-square Test
# =====================================================

chi_table = df.groupby("risk_level")[insurance_types].sum()
chi_table = chi_table.reindex(risk_order).fillna(0)

# 行列名转英文，方便输出
chi_table_english = chi_table.rename(
    index=risk_name_map,
    columns=insurance_name_map
)

print("\n=== Contingency Table: Risk Level × Insurance Type ===")
print(chi_table_english)

chi2, p_value, dof, expected = chi2_contingency(chi_table)

n = chi_table.values.sum()
min_dim = min(chi_table.shape) - 1

if min_dim > 0:
    cramers_v = np.sqrt(chi2 / (n * min_dim))
else:
    cramers_v = np.nan

print("\n=== Chi-square Test Result ===")
print(f"Chi-square statistic: {chi2:.4f}")
print(f"Degrees of freedom: {dof}")
print(f"P-value: {p_value:.6f}")
print(f"Cramer's V: {cramers_v:.4f}")

if p_value < 0.05:
    print("\nConclusion: Risk level and recommended insurance types are statistically associated.")
else:
    print("\nConclusion: No statistically significant association was detected.")

chi_result = pd.DataFrame({
    "chi_square": [chi2],
    "degrees_of_freedom": [dof],
    "p_value": [p_value],
    "cramers_v": [cramers_v]
})
# sample
# chi_result.to_csv(
#     os.path.join(base_dir, "chi_square_test_result.csv"),
#     index=False,
#     encoding="utf-8-sig"
# )
# test
chi_result.to_csv(
    os.path.join(base_dir, "test200_chi_square_test_result.csv"),
    index=False,
    encoding="utf-8-sig"
)

print("\nFiles saved in:")
print(base_dir)
print("1. risk_vs_insurance_stacked_bar.png")
print("2. questionnaire_variables_heatmap.png")
print("3. chi_square_test_result.csv")